<h1> tinyse module in giiwa framework </h1>
A memory search engine in giiwa framework